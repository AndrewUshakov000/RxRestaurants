//
//  ViewController.swift
//  RxRestaurants
//
//  Created by Andrew Ushakov on 8/12/22.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController, Storyboarded {
    @IBOutlet weak var tableView: UITableView!

    let disposedBag = DisposeBag()
    private var viewModel = RestaurantViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Restaurants"
    
        viewModel.fetchRestaurants().observe(on: MainScheduler.instance).bind(to: tableView.rx.items(cellIdentifier: "Cell")) { index, viewModel, cell in
            cell.textLabel?.text = viewModel.displayText
        }.disposed(by: disposedBag)
    }
}

