//
//  Coordinator.swift
//  RxRestaurants
//
//  Created by Andrew Ushakov on 8/15/22.
//

import Foundation
import UIKit

protocol Coordinator {
    var childCoordinator: [Coordinator] { get set }
    var navigationController: UINavigationController { get set }
    
    func start() 
}
