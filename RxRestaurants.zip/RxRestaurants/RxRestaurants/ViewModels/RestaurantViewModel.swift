//
//  RestaurantsListViewModel.swift
//  RxRestaurants
//
//  Created by Andrew Ushakov on 8/12/22.
//

import Foundation
import RxSwift

class RestaurantViewModel {
    func fetchRestaurants() -> Observable<[Restaurant]> {
        return Observable.create { observer -> Disposable in
            guard let path = Bundle.main.path(forResource: "restaurants", ofType: "json") else {
                observer.onError(NSError(domain: "", code: -1))
                return Disposables.create { }
            }
            do {
                let data = try Data(contentsOf: URL(filePath: path), options: .mappedIfSafe)
                let restaurants = try JSONDecoder().decode([Restaurant].self, from: data)
                
                observer.onNext(restaurants)
            } catch {
                observer.onError(error)
            }
            
            return Disposables.create { }
        }
    }
}
